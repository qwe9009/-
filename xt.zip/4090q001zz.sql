/*
Navicat MySQL Data Transfer

Source Server         : 11
Source Server Version : 50740
Source Host           : localhost:3306
Source Database       : zzzz

Target Server Type    : MYSQL
Target Server Version : 50740
File Encoding         : 65001

Date: 2024-04-11 16:10:56
*/

SET FOREIGN_KEY_CHECKS=0;
CREATE DATABASE db4090q001;
USE db4090q001;
-- ----------------------------
-- Table structure for categories
-- ----------------------------
DROP TABLE IF EXISTS `categories`;
CREATE TABLE `categories` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`name`)
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of categories
-- ----------------------------
INSERT INTO `categories` VALUES ('1', '電腦');
INSERT INTO `categories` VALUES ('2', '手機');
INSERT INTO `categories` VALUES ('3', '週邊設備');

-- ----------------------------
-- Table structure for orders
-- ----------------------------
DROP TABLE IF EXISTS `orders`;
CREATE TABLE `orders` (
  `order_id` bigint(20) NOT NULL AUTO_INCREMENT,
  `customer_id` bigint(20) unsigned NOT NULL,
  `order_status` tinyint(4) NOT NULL,
  `order_date` date NOT NULL,
  `required_date` date NOT NULL,
  `shipped_date` date DEFAULT NULL,
  `staff_id` bigint(20) unsigned DEFAULT NULL,
  PRIMARY KEY (`order_id`),
  KEY `customer_id` (`customer_id`),
  KEY `staff_id` (`staff_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of orders
-- ----------------------------

-- ----------------------------
-- Table structure for products
-- ----------------------------
DROP TABLE IF EXISTS `products`;
CREATE TABLE `products` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `category_id` bigint(20) unsigned NOT NULL,
  `model_year` smallint(6) NOT NULL,
  `list_price` decimal(10,2) NOT NULL,
  `picture` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `category_id` (`category_id`)
) ENGINE=MyISAM AUTO_INCREMENT=9 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of products
-- ----------------------------
INSERT INTO `products` VALUES ('2', '美光 DDR4 2666 16GB 桌上型電腦記憶體', '3', '2018', '1999.00', null);
INSERT INTO `products` VALUES ('5', 'LPC-1669 micro HDMI TO VGA 免電源轉換線(10公分) D-TYPE', '3', '2018', '382.00', null);
INSERT INTO `products` VALUES ('7', 'WD 黑標 SN750 1TB NVMe PCIe SSD固態硬碟', '3', '2019', '5660.00', null);
INSERT INTO `products` VALUES ('8', 'ASUS ROG Phone ZS600KL (8G/512G) 6吋八核電競手機', '2', '2019', '13990.00', null);

-- ----------------------------
-- Table structure for staffs
-- ----------------------------
DROP TABLE IF EXISTS `staffs`;
CREATE TABLE `staffs` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(45) NOT NULL,
  `email` varchar(255) NOT NULL,
  `phone` varchar(25) DEFAULT NULL,
  `active` tinyint(4) NOT NULL,
  `manager_id` bigint(20) unsigned DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `email` (`email`),
  KEY `manager_id` (`manager_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of staffs
-- ----------------------------

-- ----------------------------
-- Table structure for users
-- ----------------------------
DROP TABLE IF EXISTS `users`;
CREATE TABLE `users` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(15) NOT NULL,
  `email` varchar(45) NOT NULL,
  `password` char(60) NOT NULL,
  `gender` char(7) NOT NULL,
  `phone` varchar(45) DEFAULT NULL,
  `habits` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=7 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of users
-- ----------------------------
INSERT INTO `users` VALUES ('4', '123', '123@123.com', '123123123123', '帥哥', '13131313131', '逛街');
INSERT INTO `users` VALUES ('5', '123', '123@123.com', '123123123', '美女', '13131313131', '逛街');
INSERT INTO `users` VALUES ('3', '123', '123@123.com', '123123123123', '帥哥', '13131313131', '逛街');
INSERT INTO `users` VALUES ('6', '1', '123@123.com', '123123123123123', '帥哥', '13131313131', '逛街');
