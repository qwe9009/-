<?
$dbhost="localhost"; //MySQL主機位址，localhost=本機
$dbpass1="root"; //MySQL帳號
$dbpass2="123"; //MySQL密碼
$dbname="zzzz"; //資料庫名稱
$conn=mysqli_connect ($dbhost, $dbpass1, $dbpass2,$dbname); //連結MySQL資料庫

mysqli_query($conn,'set names utf8');

/*$sql_select_NO= mysql_db_query ("$dbname", "select * from noid where noid_day<>''");
@$num_NO = mysql_num_rows( $sql_select_NO );

if ($num_NO<>0) { 
while ($tb_name_NO=mysqli_fetch_field($sql_select_NO)) { $tables_NO .=$tb_name_NO->name.","; }
$table_name_NO= explode(",", $tables_NO); $tb_data_NO=mysqli_fetch_row($sql_select_NO);
for($dbno_NO=0; $dbno_NO<count($tb_data_NO); $dbno_NO++) { $$table_name_NO[$dbno_NO]=$tb_data_NO[$dbno_NO]; }
$tables_NO=""; $table_name_NO=""; 

if ($today_Ymd>$noid_day) { 
$sql= mysql_db_query ("$dbname", "Update noid Set noid_day='$today_Ymd', noid_1='0', noid_2='0', noid_3='0', noid_4='0', noid_5='0', noid_6='0', noid_7='0', noid_8='0', noid_9='0', noid_10='0' where noid_day<>''");
mysql_query($sql); } }*/
?>
